const mysql = require('mysql');

const conexion = mysql.createConnection({
    host: 'premium206.web-hosting.com',
    user: 'notrozuu_david',
    password: 'Davidcrack2002',
    database: 'notrozuu_hotel'
})
conexion.connect((error)=>{
    if(error){
        console.error('error de conexion: ' + error);
        return
    }
    console.log('Conexion completada!');
})

module.exports = conexion;